import pygame
import numpy as np
import heapq  # Para el manejo del heap en SMA*

# Inicializamos pygame
pygame.init()

# Tamaño de la celda
CELL_SIZE = 50

# Cargar las imágenes
pared = pygame.image.load('Images/Mundo/PNG/Default size/Blocks/block_08.png')
suelo = pygame.image.load('Images/Mundo/PNG/Default size/Ground/ground_06.png')
sistemito = pygame.image.load('Images/Sistemito/PNG/Side view/robot_yellowDrive1.png')
sistemito_left = pygame.image.load('Images/Sistemito/PNG/Side view/robot_yellowDrive1_left.png')

# Escala de las imágenes
pared = pygame.transform.scale(pared, (CELL_SIZE, CELL_SIZE))
suelo = pygame.transform.scale(suelo, (CELL_SIZE, CELL_SIZE))
sistemito = pygame.transform.scale(sistemito, (CELL_SIZE, CELL_SIZE))
sistemito_left = pygame.transform.scale(sistemito_left, (CELL_SIZE, CELL_SIZE))

# Definir los laberintos
mazes = [
    np.array([[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
              [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
              [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
              [1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0],
              [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0]]),
    np.array([[1, 1, 0, 1, 1],
              [1, 0, 0, 0, 1],
              [1, 0, 0, 1, 1],
              [1, 0, 0, 0, 1],
              [1, 0, 0, 0, 1],
              [1, 0, 0, 1, 1],
              [1, 0, 1, 0, 1],
              [1, 0, 0, 0, 1],
              [1, 0, 0, 0, 1],
              [1, 0, 0, 0, 1],
              [1, 1, 1, 0, 1]]),
    np.array([[1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1],
              [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
              [1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1],
              [1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1],
              [1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1]])
]

# Función de heurística (distancia Manhattan)
def heuristic(pos, exit_pos):
    return abs(pos[0] - exit_pos[0]) + abs(pos[1] - exit_pos[1])

# Implementación de SMA*
def sma_star(maze, start, exit_pos, memory_limit=50):
    frontier = []  # priority queue of open nodes
    came_from = {}  # dictionario para reconstruir el camino
    g_cost = {start: 0}  # costo del inicio del camino
    f_cost = {start: heuristic(start, exit_pos)}  # costo total del camino
    
    heapq.heappush(frontier, (f_cost[start], start))  # agregar el inicio del camino
    while frontier:
        current_f, current = heapq.heappop(frontier)
        
        if current == exit_pos:
            return reconstruct_path(came_from, current)
        
        neighbors = get_neighbors(current, maze)
        
        for neighbor in neighbors:
            tentative_g_cost = g_cost[current] + 1  # Cada movimiento tiene un costo de 1
            
            if neighbor not in g_cost or tentative_g_cost < g_cost[neighbor]:
                came_from[neighbor] = current
                g_cost[neighbor] = tentative_g_cost
                f_cost[neighbor] = g_cost[neighbor] + heuristic(neighbor, exit_pos)
                heapq.heappush(frontier, (f_cost[neighbor], neighbor))

        if len(frontier) > memory_limit:  # Limitar la memoria
            remove_least_promising(frontier, f_cost)

    return None

# Función para obtener los vecinos
def get_neighbors(pos, maze):
    neighbors = []
    x, y = pos
    if x > 0 and maze[x - 1, y] == 0:
        neighbors.append((x - 1, y))
    if x < maze.shape[0] - 1 and maze[x + 1, y] == 0:
        neighbors.append((x + 1, y))
    if y > 0 and maze[x, y - 1] == 0:
        neighbors.append((x, y - 1))
    if y < maze.shape[1] - 1 and maze[x, y + 1] == 0:
        neighbors.append((x, y + 1))
    return neighbors

# Función para reconstruir el camino
def reconstruct_path(came_from, current):
    path = [current]
    while current in came_from:
        current = came_from[current]
        path.append(current)
    return path[::-1]

# Función para eliminar el nodo menos prometedor
def remove_least_promising(frontier, f_cost):
    frontier.sort(key=lambda x: f_cost[x[1]], reverse=True)  # Ordenar por costo
    frontier.pop()  # Eliminar el nodo menos prometedor

# Función para el juego
def game(level):
    global screen
    maze = mazes[level]

    # Ajustar el tamaño de la ventana según el laberinto
    width = maze.shape[1] * CELL_SIZE
    height = maze.shape[0] * CELL_SIZE
    screen = pygame.display.set_mode((width, height))

    # Posiciones iniciales y finales del jugador según el nivel
    if level == 0:
        player_pos = [0, 0]  # Posición inicial del jugador para el laberinto 1
        exit_pos = [4, 10]   # Posición de salida para el laberinto 1
    elif level == 1:
        player_pos = [0, 2]  # Posición inicial del jugador para el laberinto 2
        exit_pos = [10, 3]   # Posición de salida para el laberinto 2
    elif level == 2:
        player_pos = [0, 2]  # Posición inicial del jugador para el laberinto 2
        exit_pos = [0, 8]   # Posición de salida para el laberinto 2

    path = sma_star(maze, tuple(player_pos), tuple(exit_pos))  # Ejecutar SMA*
    
    if path:
        print("¡Camino encontrado!")
        for step in path:
            draw_maze(maze)
            screen.blit(sistemito, (step[1] * CELL_SIZE, step[0] * CELL_SIZE))
            pygame.display.flip()
            pygame.time.delay(300)  # Pequeña pausa para visualizar el movimiento
    else:
        print("No se encontró camino.")

# Función para dibujar el laberinto
def draw_maze(maze):
    for y in range(maze.shape[0]):
        for x in range(maze.shape[1]):
            if maze[y, x] == 1:
                screen.blit(pared, (x * CELL_SIZE, y * CELL_SIZE))  # Dibuja la pared
            else:
                screen.blit(suelo, (x * CELL_SIZE, y * CELL_SIZE))  # Dibuja el suelo

# Pantalla principal
def main_menu():
    global screen
    screen = pygame.display.set_mode((500, 500))
    running = True
    while running:
        screen.fill((128, 128, 128))
        font = pygame.font.SysFont(None, 48)
        title = font.render("Juego de Laberinto", True, (0, 0, 0))
        screen.blit(title, (250 - title.get_width() // 2, 50))

        # Botones de nivel
        for i in range(3):  # Cambiado a 3 para incluir el tercer nivel
            button = pygame.draw.rect(screen, (255, 0, 0), (250 - 60, 150 + i * 60, 135, 50))
            button_text = font.render(f"Nivel {i + 1}", True, (255, 255, 255))
            screen.blit(button_text, (button.x + 15, button.y + 10))

            # Comprobar si se hace clic en el botón
            mouse = pygame.mouse.get_pos()
            if button.collidepoint(mouse) and pygame.mouse.get_pressed()[0]:
                game(i)  # Iniciar el nivel seleccionado

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

# Ejecutar el juego
if __name__ == "__main__":
    main_menu()
    pygame.quit()
